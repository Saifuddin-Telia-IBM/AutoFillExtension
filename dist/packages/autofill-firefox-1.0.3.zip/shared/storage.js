/**
 * shared/storage.js  (v2 — profile-aware)
 *
 * Data shape stored under key "autofillRules":
 * {
 *   "<urlPattern>": {
 *     "aliases": ["<extra pattern>", ...],   // optional — additional URL patterns
 *     "profiles": [
 *       {
 *         "id": "uuid",
 *         "name": "Profile name",
 *         "rules": [ { id, enabled, selector, type, value, label? }, ... ]
 *       },
 *       ...
 *     ]
 *   },
 *   ...
 * }
 *
 * On first load, any legacy flat-array format is silently migrated to the
 * new shape by wrapping the array into a single profile named "Default".
 */

'use strict';

const STORAGE_KEY = 'autofillRules';

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function generateId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

function stripHash(url) {
  try {
    const u = new URL(url);
    u.hash = '';
    return u.toString();
  } catch {
    return url;
  }
}

/** Base URL = URL without hash (and without a trailing wildcard). Used to group patterns. */
function baseUrlOf(url) {
  const clean = stripHash(url);
  return clean.endsWith('*') ? clean.slice(0, -1) : clean;
}

function patternMatches(urlPattern, url) {
  // Pattern targets a specific hash route (SPA): compare against the full URL, hash included.
  if (urlPattern.includes('#')) {
    if (urlPattern === url) return true;
    return urlPattern.endsWith('*') && url.startsWith(urlPattern.slice(0, -1));
  }
  const cleanUrl = stripHash(url);
  if (urlPattern === cleanUrl) return true;
  if (urlPattern.endsWith('*')) {
    if (cleanUrl.startsWith(urlPattern.slice(0, -1))) return true;
  }
  try {
    const base = urlPattern.endsWith('*') ? urlPattern.slice(0, -1) : urlPattern;
    const patUrl = new URL(base);
    const pageUrl = new URL(cleanUrl);
    if (
      patUrl.hostname === pageUrl.hostname &&
      patUrl.protocol === pageUrl.protocol &&
      (patUrl.pathname === '/' || patUrl.pathname === '')
    ) return true;
  } catch { /* not a valid URL */ }
  return false;
}

/**
 * Migrate a legacy flat-array value to the new profile-based shape.
 * If it already has the new shape, return as-is.
 */
function migratePatternValue(value) {
  if (!value) return { profiles: [] };
  // Already migrated (aliases field is optional — just ensure profiles exists)
  if (value.profiles) return value;
  // Legacy: value is an array of rules
  if (Array.isArray(value)) {
    return {
      profiles: [{
        id: generateId(),
        name: 'Default',
        rules: value,
      }],
    };
  }
  return { profiles: [] };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/** Load and migrate the full rules map from storage. */
async function getAllRules() {
  const result = await browser.storage.local.get(STORAGE_KEY);
  const raw = result[STORAGE_KEY] || {};
  // Migrate any legacy entries in-place
  const migrated = {};
  let needsSave = false;
  for (const [pattern, value] of Object.entries(raw)) {
    const m = migratePatternValue(value);
    migrated[pattern] = m;
    if (m !== value) needsSave = true;
  }
  if (needsSave) await browser.storage.local.set({ [STORAGE_KEY]: migrated });
  return migrated;
}

/** Persist the full rules map. */
async function saveRules(rules) {
  await browser.storage.local.set({ [STORAGE_KEY]: rules });
}

/**
 * Return all profiles (with only their enabled rules) for matching URL patterns.
 * Each returned profile may come from a different pattern (all matches collected).
 * @returns {Promise<Array<{ id, name, rules, patternKey }>>}
 */
async function getProfilesForUrl(url) {
  const all = await getAllRules();
  const result = [];
  for (const [pattern, data] of Object.entries(all)) {
    const allPatterns = [pattern, ...(data.aliases || [])];
    if (!allPatterns.some(p => patternMatches(p, url))) continue;
    for (const profile of (data.profiles || [])) {
      const enabledRules = (profile.rules || []).filter(r => r.enabled);
      if (enabledRules.length > 0) {
        result.push({
          id: profile.id,
          name: profile.name,
          rules: enabledRules,
          patternKey: pattern,
        });
      }
    }
  }
  return result;
}

/** Return the raw pattern data (profiles array) for an exact pattern key. */
async function getPatternData(urlPattern) {
  const all = await getAllRules();
  return all[urlPattern] || { profiles: [] };
}

/** Return matching pattern keys for a URL. */
async function getMatchingPatterns(url) {
  const all = await getAllRules();
  return Object.keys(all).filter(p => {
    const data = all[p];
    const allPatterns = [p, ...(data.aliases || [])];
    return allPatterns.some(pat => patternMatches(pat, url));
  });
}

// --- Pattern-level ---

// --- Alias-level ---

/** Add an alias URL pattern to an existing pattern entry. */
async function addAlias(urlPattern, alias) {
  const all = await getAllRules();
  if (!all[urlPattern]) return;
  if (!all[urlPattern].aliases) all[urlPattern].aliases = [];
  if (!all[urlPattern].aliases.includes(alias)) {
    all[urlPattern].aliases.push(alias);
    await saveRules(all);
  }
}

/** Remove an alias URL pattern from an existing pattern entry. */
async function removeAlias(urlPattern, alias) {
  const all = await getAllRules();
  if (!all[urlPattern] || !all[urlPattern].aliases) return;
  all[urlPattern].aliases = all[urlPattern].aliases.filter(a => a !== alias);
  await saveRules(all);
}

// --- Pattern-level ---

/**
 * Rename a URL pattern key, preserving all its profiles and aliases.
 * No-op if oldPattern doesn't exist or newPattern already exists.
 */
async function renamePattern(oldPattern, newPattern) {
  if (!oldPattern || !newPattern || oldPattern === newPattern) return;
  const all = await getAllRules();
  if (!all[oldPattern] || all[newPattern]) return;
  all[newPattern] = all[oldPattern];
  delete all[oldPattern];
  await saveRules(all);
}

/** Rename a single alias on a pattern entry. */
async function renameAlias(urlPattern, oldAlias, newAlias) {
  if (!oldAlias || !newAlias || oldAlias === newAlias) return;
  const all = await getAllRules();
  if (!all[urlPattern] || !all[urlPattern].aliases) return;
  const idx = all[urlPattern].aliases.indexOf(oldAlias);
  if (idx === -1) return;
  // Avoid duplicates
  if (all[urlPattern].aliases.includes(newAlias)) return;
  all[urlPattern].aliases[idx] = newAlias;
  await saveRules(all);
}

/** Ensure a URL pattern key exists in storage. */
async function ensurePattern(urlPattern) {
  const all = await getAllRules();
  if (!all[urlPattern]) {
    all[urlPattern] = { profiles: [] };
    await saveRules(all);
  }
}

/** Delete an entire URL pattern. */
async function deletePattern(urlPattern) {
  const all = await getAllRules();
  delete all[urlPattern];
  await saveRules(all);
}

// --- Profile-level ---

/**
 * Add a new profile under a URL pattern.
 * @returns {Promise<string>} new profile id
 */
async function addProfile(urlPattern, name) {
  const all = await getAllRules();
  if (!all[urlPattern]) all[urlPattern] = { profiles: [] };
  const id = generateId();
  all[urlPattern].profiles.push({ id, name, rules: [] });
  await saveRules(all);
  return id;
}

/** Rename a profile. */
async function renameProfile(urlPattern, profileId, newName) {
  const all = await getAllRules();
  const profile = _findProfile(all, urlPattern, profileId);
  if (profile) profile.name = newName;
  await saveRules(all);
}

/** Delete a profile. */
async function deleteProfile(urlPattern, profileId) {
  const all = await getAllRules();
  if (!all[urlPattern]) return;
  all[urlPattern].profiles = all[urlPattern].profiles.filter(p => p.id !== profileId);
  if (all[urlPattern].profiles.length === 0) delete all[urlPattern];
  await saveRules(all);
}

// --- Rule-level ---

/** Add a rule to a specific profile. @returns {Promise<string>} rule id */
async function addRule(urlPattern, profileId, fieldRule) {
  const all = await getAllRules();
  const profile = _findProfile(all, urlPattern, profileId);
  if (!profile) return;
  const id = generateId();
  profile.rules.push({
    id,
    enabled: true,
    selector: fieldRule.selector,
    type: fieldRule.type,
    value: fieldRule.value,
    label: fieldRule.label || '',
  });
  await saveRules(all);
  return id;
}

/** Update specific fields of a rule. */
async function updateRule(urlPattern, profileId, ruleId, patch) {
  const all = await getAllRules();
  const profile = _findProfile(all, urlPattern, profileId);
  if (!profile) return;
  const idx = profile.rules.findIndex(r => r.id === ruleId);
  if (idx === -1) return;
  profile.rules[idx] = { ...profile.rules[idx], ...patch };
  await saveRules(all);
}

/** Delete a rule. */
async function deleteRule(urlPattern, profileId, ruleId) {
  const all = await getAllRules();
  const profile = _findProfile(all, urlPattern, profileId);
  if (!profile) return;
  profile.rules = profile.rules.filter(r => r.id !== ruleId);
  await saveRules(all);
}

/** Import (replace all) rules. */
async function importRules(rules) {
  await saveRules(rules);
}

// ---------------------------------------------------------------------------
// Internal
// ---------------------------------------------------------------------------

function _findProfile(all, urlPattern, profileId) {
  const data = all[urlPattern];
  if (!data) return null;
  return data.profiles.find(p => p.id === profileId) || null;
}
