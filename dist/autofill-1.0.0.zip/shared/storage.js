/**
 * shared/storage.js
 *
 * Storage helpers for AutoFill extension.
 * Can be used from popup, options page, and background script.
 *
 * Data shape stored under key "autofillRules":
 * {
 *   "<urlPattern>": [ { id, enabled, selector, type, value, label? }, ... ],
 *   ...
 * }
 *
 * URL pattern matching (in priority order):
 *   1. Exact match  — stored key === normalised URL (no hash)
 *   2. Glob/prefix  — stored key ends with '*', prefix before '*' matches start of URL
 *   3. Hostname     — stored key has no path (just scheme+host), matches any path on that host
 */

'use strict';

const STORAGE_KEY = 'autofillRules';

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/**
 * Generate a simple UUID v4.
 * Uses crypto.randomUUID when available (FF 95+), falls back to manual impl.
 */
function generateId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Manual fallback
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Strip the hash from a URL string and return the clean URL.
 */
function stripHash(url) {
  try {
    const u = new URL(url);
    u.hash = '';
    return u.toString();
  } catch {
    return url;
  }
}

/**
 * Test whether `urlPattern` (a stored key) matches `url`.
 */
function patternMatches(urlPattern, url) {
  const cleanUrl = stripHash(url);

  // 1. Exact match
  if (urlPattern === cleanUrl) return true;

  // 2. Glob prefix — pattern ends with '*'
  if (urlPattern.endsWith('*')) {
    const prefix = urlPattern.slice(0, -1);
    if (cleanUrl.startsWith(prefix)) return true;
  }

  // 3. Hostname-only pattern — no path component beyond '/'
  try {
    const patUrl = new URL(urlPattern.endsWith('*') ? urlPattern.slice(0, -1) : urlPattern);
    const pageUrl = new URL(cleanUrl);
    if (
      patUrl.hostname === pageUrl.hostname &&
      patUrl.protocol === pageUrl.protocol &&
      (patUrl.pathname === '/' || patUrl.pathname === '')
    ) {
      return true;
    }
  } catch {
    // not a valid URL pattern — skip
  }

  return false;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Load the full rules map from storage.
 * @returns {Promise<Object>} map of urlPattern → rule[]
 */
async function getAllRules() {
  const result = await browser.storage.local.get(STORAGE_KEY);
  return result[STORAGE_KEY] || {};
}

/**
 * Persist the full rules map to storage.
 * @param {Object} rules
 */
async function saveRules(rules) {
  await browser.storage.local.set({ [STORAGE_KEY]: rules });
}

/**
 * Return the enabled rules that match the given URL.
 * Collects rules from ALL matching patterns (exact + glob + hostname).
 * @param {string} url
 * @returns {Promise<Array>}
 */
async function getRulesForUrl(url) {
  const all = await getAllRules();
  const matched = [];
  for (const [pattern, rules] of Object.entries(all)) {
    if (patternMatches(pattern, url)) {
      for (const rule of rules) {
        if (rule.enabled) matched.push(rule);
      }
    }
  }
  return matched;
}

/**
 * Return all rules (including disabled) for a given URL pattern key.
 * This is used by the popup to show rules for the current page pattern.
 * @param {string} urlPattern - exact stored key
 * @returns {Promise<Array>}
 */
async function getRulesForPattern(urlPattern) {
  const all = await getAllRules();
  return all[urlPattern] || [];
}

/**
 * Find which stored pattern key(s) match a given URL.
 * Returns an array of matching pattern strings.
 * @param {string} url
 * @returns {Promise<string[]>}
 */
async function getMatchingPatterns(url) {
  const all = await getAllRules();
  return Object.keys(all).filter(p => patternMatches(p, url));
}

/**
 * Add a new rule under the given URL pattern.
 * @param {string} urlPattern
 * @param {{ selector: string, type: string, value: *, label?: string }} fieldRule
 * @returns {Promise<string>} the generated rule id
 */
async function addRule(urlPattern, fieldRule) {
  const all = await getAllRules();
  if (!all[urlPattern]) all[urlPattern] = [];
  const id = generateId();
  all[urlPattern].push({
    id,
    enabled: true,
    selector: fieldRule.selector,
    type: fieldRule.type,
    value: fieldRule.value,
    label: fieldRule.label || '',
  });
  await saveRules(all);
  return id;
}

/**
 * Update specific fields of an existing rule.
 * @param {string} urlPattern
 * @param {string} ruleId
 * @param {Object} patch - partial rule fields to merge
 */
async function updateRule(urlPattern, ruleId, patch) {
  const all = await getAllRules();
  const rules = all[urlPattern];
  if (!rules) return;
  const idx = rules.findIndex(r => r.id === ruleId);
  if (idx === -1) return;
  rules[idx] = { ...rules[idx], ...patch };
  await saveRules(all);
}

/**
 * Delete a rule by id under a URL pattern.
 * @param {string} urlPattern
 * @param {string} ruleId
 */
async function deleteRule(urlPattern, ruleId) {
  const all = await getAllRules();
  if (!all[urlPattern]) return;
  all[urlPattern] = all[urlPattern].filter(r => r.id !== ruleId);
  if (all[urlPattern].length === 0) delete all[urlPattern];
  await saveRules(all);
}

/**
 * Delete an entire URL pattern and all its rules.
 * @param {string} urlPattern
 */
async function deletePattern(urlPattern) {
  const all = await getAllRules();
  delete all[urlPattern];
  await saveRules(all);
}

/**
 * Replace all rules with imported data.
 * @param {Object} rules - full rules map
 */
async function importRules(rules) {
  await saveRules(rules);
}
